"""
train_kd.py
Knowledge distillation for noise-robust end-to-end SLU on SLURP.

  Teacher : NVIDIA NeMo slu_conformer_transformer_large_slurp (frozen, CLEAN audio)
  Student : HubertSLUModel from model.py (trained on NOISY audio, default 5 dB SNR)

Loss (student always sees the noisy waveform):

  L = CE(intent, gold) + w_ctc * CTC(tagged transcript, gold)          # supervised
    + w_int  * T^2 * KL(teacher intent posterior || student)  @ temp T  # intent KD
    + w_feat * (1 - cos(proj(student slot feats), teacher encoder))   # feature KD
    + w_slot * CTC(tagged transcript built from TEACHER entities)       # slot KD

  * Intent KD: the teacher's posterior over the student's intent labels, obtained
    by teacher-forcing "{'scenario': 'X', 'action': 'Y'," for every intent.
  * Feature KD: the student's slot-branch features (input of the BiLSTM) on noisy
    audio are pulled toward the teacher's clean-audio Conformer states. This is
    the main denoising signal: the student learns representations that look
    like what an SLU model sees on clean speech, where the slot spans are.
  * Slot KD: the teacher's decoded entities are projected onto the transcript as
    <fill_TYPE> ... <end_fill> spans (see teacher_nemo.semantics_to_tagged_text)
    and used as an extra CTC target. With --kd_slot_filter agree (default) it is
    only used when the teacher's intent on that utterance matches the gold intent.

Teacher outputs for clean audio are deterministic, so intent posteriors and
entity decodes are cached per audio file (saved to <output_dir>/teacher_cache.pt);
only the encoder pass runs every step (needed for feature KD).

Example:
    python train_kd.py \
        --slurp_jsonl_dir /data/slurp/dataset/slurp \
        --audio_root /data/slurp/audio \
        --noise_dir /data/musan/noise \
        --snr_db 5 \
        --output_dir ./ckpt_kd \
        --hubert_name facebook/hubert-base-ls960 \
        --layer_fusion weighted_sum \
        --epochs 20 --batch_size 8 --lr 3e-5 \
        --eval_teacher

The saved best_model.pt is a plain HubertSLUModel state_dict, so the existing
infer.py works on it unchanged.
"""
import argparse
import functools
import json
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from tqdm import tqdm

from vocab import build_label_maps
from model import HubertSLUModel
from metrics import intent_accuracy, slu_f1
from train import build_or_load_vocabs
from kd_dataset import KDSlurpDataset, kd_collate_fn
from teacher_nemo import (
    DEFAULT_NEMO_PATH, NemoSLUTeacher, download_teacher, parse_semantics,
    semantics_intent, semantics_to_tagged_text, entities_to_tagged_text,
)


# --------------------------------------------------------------------------- #
def parse_args():
    p = argparse.ArgumentParser()
    # --- data / student (same meaning as train.py) ---
    p.add_argument("--slurp_jsonl_dir", required=True)
    p.add_argument("--audio_root", required=True, help="CLEAN SLURP audio (slurp_real/, slurp_synth/)")
    p.add_argument("--output_dir", default="./ckpt_kd")
    p.add_argument("--hubert_name", default="facebook/hubert-base-ls960")
    p.add_argument("--semantic_layer", type=int, default=8)
    p.add_argument("--vocab_type", choices=["char", "bpe"], default="char")
    p.add_argument("--bpe_vocab_size", type=int, default=500)
    p.add_argument("--layer_fusion", choices=["single", "weighted_sum"], default="single")
    p.add_argument("--fusion_layers", type=str, default=None)
    p.add_argument("--freeze_encoder_layers", type=int, default=0)
    p.add_argument("--init_student", default=None,
                   help="Optional student checkpoint to start from (e.g. clean-trained best_model.pt)")
    p.add_argument("--epochs", type=int, default=20)
    p.add_argument("--batch_size", type=int, default=8)
    p.add_argument("--lr", type=float, default=3e-5)
    p.add_argument("--head_lr_mult", type=float, default=20.0)
    p.add_argument("--ctc_loss_weight", type=float, default=1.0)
    p.add_argument("--num_workers", type=int, default=4)
    p.add_argument("--max_audio_seconds", type=float, default=15.0)
    p.add_argument("--grad_clip", type=float, default=5.0)
    p.add_argument("--log_every", type=int, default=50)
    p.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")

    # --- noise ---
    p.add_argument("--noise_dir", default=None, help="Folder of noise recordings for on-the-fly mixing")
    p.add_argument("--dev_noise_dir", default=None,
                   help="Separate noise folder for dev (recommended: unseen noise). Default: --noise_dir")
    p.add_argument("--noisy_audio_root", default=None,
                   help="Alternative: pre-mixed noisy SLURP audio with the same file names")
    p.add_argument("--snr_db", type=float, default=5.0)

    # --- teacher ---
    p.add_argument("--teacher_nemo", default=DEFAULT_NEMO_PATH,
                   help="Path to slu_conformer_transformer_large_slurp.nemo (downloaded if missing)")
    p.add_argument("--teacher_device", default=None, help="Default: same as --device")
    p.add_argument("--teacher_input", choices=["clean", "noisy"], default="clean")
    p.add_argument("--teacher_intent_chunk", type=int, default=16)

    # --- distillation weights ---
    p.add_argument("--kd_intent_weight", type=float, default=1.0)
    p.add_argument("--kd_temperature", type=float, default=2.0)
    p.add_argument("--kd_feat_weight", type=float, default=0.5)
    p.add_argument("--kd_slot_weight", type=float, default=0.5)
    p.add_argument("--kd_slot_filter", choices=["agree", "all"], default="agree")

    # --- evaluation ---
    p.add_argument("--eval_teacher", action="store_true",
                   help="Score the teacher on the noisy (and clean) dev set once, as a reference")
    p.add_argument("--eval_clean", action="store_true",
                   help="Also evaluate the student on clean dev audio each epoch")
    return p.parse_args()


# --------------------------------------------------------------------------- #
def intent_to_scenario_action(train_jsonl):
    """Intent label -> (scenario, action). Read from data because both parts can
    contain underscores (e.g. iot_hue_lightoff), so splitting the label is ambiguous."""
    mapping = {}
    with open(train_jsonl) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rec = json.loads(line)
            sc, ac = rec.get("scenario"), rec.get("action")
            if sc is not None and ac is not None:
                mapping.setdefault(rec.get("intent", f"{sc}_{ac}"), (sc, ac))
                mapping.setdefault(f"{sc}_{ac}", (sc, ac))
    return mapping


class FeatureTap:
    """Captures the input of a module (here: the slot BiLSTM) without editing model.py."""
    def __init__(self, module):
        self.feats = None
        module.register_forward_pre_hook(self._hook)

    def _hook(self, module, inputs):
        self.feats = inputs[0]


def feature_kd_loss(student_feats, teacher_feats, teacher_lens, proj):
    """1 - cosine between projected student frames (20 ms) and teacher frames (40 ms)."""
    s = proj(student_feats)                                   # (B, Ts, D_t)
    Tt = teacher_feats.shape[1]
    s = F.interpolate(s.transpose(1, 2), size=Tt, mode="linear", align_corners=False).transpose(1, 2)
    mask = (torch.arange(Tt, device=s.device)[None, :] < teacher_lens[:, None]).float()
    cos = F.cosine_similarity(s, teacher_feats, dim=-1)
    return ((1.0 - cos) * mask).sum() / mask.sum().clamp(min=1.0)


# --------------------------------------------------------------------------- #
class TeacherKnowledge:
    """Runs the teacher and caches per-file intent posteriors / slot targets."""

    def __init__(self, teacher, args, intent_list, slot_types, cache_path):
        self.t = teacher
        self.args = args
        self.intent_list = intent_list
        self.slot_types = set(slot_types)
        self.use_cache = args.teacher_input == "clean"
        self.cache_path = cache_path
        self.cache = {}
        if self.use_cache and cache_path.exists():
            blob = torch.load(cache_path, map_location="cpu", weights_only=False)
            if blob.get("intent_list") == intent_list:
                self.cache = blob["entries"]
                print(f"[teacher] loaded cache with {len(self.cache)} entries")

    def save(self):
        if self.use_cache:
            torch.save({"intent_list": self.intent_list, "entries": self.cache}, self.cache_path)

    @torch.no_grad()
    def __call__(self, batch):
        """Returns teacher encoder states/lengths (on teacher device) and per-item entries."""
        tdev = self.t.device
        wav = batch["clean_values"] if self.args.teacher_input == "clean" else batch["input_values"]
        wav_lens = batch["attention_mask"].sum(-1)
        enc, enc_lens = self.t.encode(wav.to(tdev), wav_lens.to(tdev))

        files = batch["audio_files"]
        store = self.cache if self.use_cache else {}
        want_int, want_slot = self.args.kd_intent_weight > 0, self.args.kd_slot_weight > 0

        def incomplete(e):
            return (e is None or (want_int and e.get("intent_lp") is None)
                    or (want_slot and "slot_target" not in e))

        need = [i for i, f in enumerate(files) if incomplete(store.get(f))]
        if need and (want_int or want_slot):
            idx = torch.tensor(need, device=tdev)
            sub_enc, sub_lens = enc[idx], enc_lens[idx]
            lps = self.t.intent_logprobs(sub_enc, sub_lens).cpu() if self.args.kd_intent_weight > 0 else None
            sems = self.t.decode(sub_enc, sub_lens) if self.args.kd_slot_weight > 0 else None
            for j, i in enumerate(need):
                entry = {"intent_lp": lps[j].half() if lps is not None else None}
                if sems is not None:
                    sem = parse_semantics(sems[j])
                    gold_intent = self.intent_list[int(batch["intent_ids"][i])]
                    entry["agree"] = semantics_intent(sem) == gold_intent
                    entry["slot_target"] = semantics_to_tagged_text(
                        sem, batch["tagged_texts"][i], self.slot_types)
                store[files[i]] = entry
        entries = [store.get(f, {}) for f in files]
        return enc, enc_lens, entries


# --------------------------------------------------------------------------- #
@torch.no_grad()
def evaluate_student(student, loader, device, ctc_vocab, key="input_values"):
    student.eval()
    pi, gi, pt, gt = [], [], [], []
    for batch in loader:
        out = student(batch[key].to(device), batch["attention_mask"].to(device))
        pi += out["intent_logits"].argmax(-1).tolist()
        gi += batch["intent_ids"].tolist()
        ids = out["ctc_log_probs"].argmax(-1).transpose(0, 1).tolist()
        for seq, L in zip(ids, out["feat_lens"].tolist()):
            pt.append(ctc_vocab.decode(seq[:L]))
        gt += batch["tagged_texts"]
    student.train()
    return {"intent_accuracy": intent_accuracy(pi, gi), **slu_f1(pt, gt)}


@torch.no_grad()
def evaluate_teacher(teacher, loader, intent2id, key):
    pi, gi, pt, gt = [], [], [], []
    for batch in tqdm(loader, desc=f"teacher eval ({key})"):
        enc, lens = teacher.encode(batch[key].to(teacher.device),
                                   batch["attention_mask"].sum(-1).to(teacher.device))
        for s in teacher.decode(enc, lens):
            sem = parse_semantics(s)
            pi.append(intent2id.get(semantics_intent(sem), -1))
            pt.append(entities_to_tagged_text(sem))
        gi += batch["intent_ids"].tolist()
        gt += batch["tagged_texts"]
    return {"intent_accuracy": intent_accuracy(pi, gi), **slu_f1(pt, gt)}


def fmt(m):
    return (f"intent_acc={m['intent_accuracy']:.4f} slu_f1={m['f1']:.4f} "
            f"(P={m['precision']:.4f} R={m['recall']:.4f})")


# --------------------------------------------------------------------------- #
def main():
    args = parse_args()
    if (args.noise_dir is None) == (args.noisy_audio_root is None):
        raise SystemExit("Give exactly one of --noise_dir or --noisy_audio_root")
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "kd_args.json").write_text(json.dumps(vars(args), indent=2))
    tdev = args.teacher_device or args.device
    train_jsonl = Path(args.slurp_jsonl_dir) / "train.jsonl"

    # ---- labels ----
    intent_list, intent2id, ctc_vocab = build_or_load_vocabs(args, out_dir)
    _, slot_types = build_label_maps([train_jsonl])
    i2sa = intent_to_scenario_action(train_jsonl)
    print(f"[vocab] {len(intent_list)} intents, {len(slot_types)} slot types, {len(ctc_vocab)} CTC symbols")

    # ---- data ----
    common = dict(ctc_vocab=ctc_vocab, intent2id=intent2id, max_audio_seconds=args.max_audio_seconds,
                  snr_db=args.snr_db, noisy_audio_root=args.noisy_audio_root)
    train_ds = KDSlurpDataset(train_jsonl, args.audio_root, noise_dir=args.noise_dir,
                              deterministic=False, **common)
    dev_ds = KDSlurpDataset(Path(args.slurp_jsonl_dir) / "devel.jsonl", args.audio_root,
                            noise_dir=(args.dev_noise_dir or args.noise_dir) if args.noise_dir else None,
                            deterministic=True, **common)
    print(f"[data] train={len(train_ds)} dev={len(dev_ds)} snr={args.snr_db} dB")
    collate = functools.partial(kd_collate_fn, pad_id=ctc_vocab.pad_id)
    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True,
                              num_workers=args.num_workers, collate_fn=collate, drop_last=True)
    dev_loader = DataLoader(dev_ds, batch_size=args.batch_size, shuffle=False,
                            num_workers=args.num_workers, collate_fn=collate)

    # ---- student ----
    student = HubertSLUModel(
        num_intents=len(intent_list), ctc_vocab_size=len(ctc_vocab),
        pad_id=ctc_vocab.pad_id, blank_id=ctc_vocab.blank_id,
        hubert_name=args.hubert_name, semantic_layer=args.semantic_layer,
        layer_fusion=args.layer_fusion,
        fusion_layers=[int(x) for x in args.fusion_layers.split(",")] if args.fusion_layers else None,
        freeze_feature_extractor=True, freeze_encoder_layers=args.freeze_encoder_layers,
    )
    if args.init_student:
        student.load_state_dict(torch.load(args.init_student, map_location="cpu"))
        print(f"[student] initialised from {args.init_student}")
    student.to(args.device)
    slot_tap = FeatureTap(student.slot_lstm)

    # ---- teacher ----
    teacher = NemoSLUTeacher(download_teacher(args.teacher_nemo), intent_list, i2sa, tdev,
                             intent_chunk=args.teacher_intent_chunk)
    knowledge = TeacherKnowledge(teacher, args, intent_list, slot_types, out_dir / "teacher_cache.pt")
    hidden = student.hubert.config.hidden_size
    kd_proj = nn.Sequential(nn.LayerNorm(hidden), nn.Linear(hidden, teacher.dim)).to(args.device)
    print(f"[teacher] encoder dim={teacher.dim}; student hidden={hidden}; teacher input={args.teacher_input}")

    if args.eval_teacher:
        print(f"[teacher] dev noisy ({args.snr_db} dB): {fmt(evaluate_teacher(teacher, dev_loader, intent2id, 'input_values'))}")
        print(f"[teacher] dev clean        : {fmt(evaluate_teacher(teacher, dev_loader, intent2id, 'clean_values'))}")

    # ---- optimiser (same scheme as train.py; KD projection counts as a head) ----
    enc_params = [p for p in student.hubert.parameters() if p.requires_grad]
    head_mods = [student.intent_pool, student.intent_head, student.slot_lstm, student.ctc_head, kd_proj]
    if args.layer_fusion == "weighted_sum":
        head_mods += [student.intent_layer_fusion, student.slot_layer_fusion]
    head_params = [p for m in head_mods for p in m.parameters() if p.requires_grad]
    head_lr = args.lr * args.head_lr_mult
    optimizer = torch.optim.AdamW([{"params": enc_params, "lr": args.lr},
                                   {"params": head_params, "lr": head_lr}])
    total_steps = max(1, args.epochs * len(train_loader))
    scheduler = torch.optim.lr_scheduler.OneCycleLR(optimizer, max_lr=[args.lr, head_lr],
                                                    total_steps=total_steps)
    all_params = list(student.parameters()) + list(kd_proj.parameters())

    # ---- training ----
    T = args.kd_temperature
    best_f1, step = -1.0, 0
    for epoch in range(args.epochs):
        student.train()
        running = {}
        pbar = tqdm(train_loader, desc=f"epoch {epoch}")
        for batch in pbar:
            t_enc, t_lens, entries = knowledge(batch)

            batch = {k: (v.to(args.device) if torch.is_tensor(v) else v) for k, v in batch.items()}
            out = student(batch["input_values"], batch["attention_mask"])
            loss, l_int, l_ctc = student.compute_loss(batch, out, ctc_loss_weight=args.ctc_loss_weight)
            logs = {"int": float(l_int), "ctc": float(l_ctc)}

            # intent KD
            if args.kd_intent_weight > 0 and all(e.get("intent_lp") is not None for e in entries):
                t_lp = torch.stack([e["intent_lp"] for e in entries]).float().to(args.device)
                kd_int = F.kl_div(F.log_softmax(out["intent_logits"] / T, -1),
                                  F.log_softmax(t_lp / T, -1),
                                  log_target=True, reduction="batchmean") * T * T
                loss = loss + args.kd_intent_weight * kd_int
                logs["kd_int"] = float(kd_int)

            # feature KD
            if args.kd_feat_weight > 0:
                kd_feat = feature_kd_loss(slot_tap.feats, t_enc.to(args.device).float(),
                                          t_lens.to(args.device), kd_proj)
                loss = loss + args.kd_feat_weight * kd_feat
                logs["kd_feat"] = float(kd_feat)

            # slot KD (teacher's slot-filled transcript as extra CTC target)
            if args.kd_slot_weight > 0:
                sel, tgts = [], []
                for i, e in enumerate(entries):
                    tgt = e.get("slot_target")
                    if not tgt or (args.kd_slot_filter == "agree" and not e.get("agree")):
                        continue
                    ids = ctc_vocab.encode(tgt)
                    if ids:
                        sel.append(i)
                        tgts.append(torch.tensor(ids, dtype=torch.long))
                if sel:
                    lens = torch.tensor([len(t) for t in tgts], device=args.device)
                    padded = torch.nn.utils.rnn.pad_sequence(
                        tgts, batch_first=True, padding_value=ctc_vocab.pad_id).to(args.device)
                    sel_t = torch.tensor(sel, device=args.device)
                    kd_slot = F.ctc_loss(out["ctc_log_probs"][:, sel_t], padded,
                                         out["feat_lens"][sel_t], lens,
                                         blank=ctc_vocab.blank_id, zero_infinity=True)
                    loss = loss + args.kd_slot_weight * kd_slot
                    logs["kd_slot"] = float(kd_slot)

            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(all_params, args.grad_clip)
            optimizer.step()
            scheduler.step()

            step += 1
            logs["loss"] = float(loss)
            for k, v in logs.items():
                running[k] = 0.98 * running.get(k, v) + 0.02 * v
            if step % args.log_every == 0:
                pbar.set_postfix({k: f"{v:.3f}" for k, v in running.items()})

        knowledge.save()

        m = evaluate_student(student, dev_loader, args.device, ctc_vocab, "input_values")
        print(f"[epoch {epoch}] student dev noisy ({args.snr_db} dB): {fmt(m)}")
        if args.eval_clean:
            mc = evaluate_student(student, dev_loader, args.device, ctc_vocab, "clean_values")
            print(f"[epoch {epoch}] student dev clean        : {fmt(mc)}")
        fw = student.log_layer_fusion_weights()
        if fw is not None:
            print(f"    intent layer weights: {[round(w, 3) for w in fw['intent']]}")
            print(f"    slot   layer weights: {[round(w, 3) for w in fw['slot']]}")

        if m["f1"] > best_f1:
            best_f1 = m["f1"]
            torch.save(student.state_dict(), out_dir / "best_model.pt")
            print(f"[epoch {epoch}] new best (noisy dev slu_f1={best_f1:.4f}) -> best_model.pt")

    torch.save(student.state_dict(), out_dir / "last_model.pt")


if __name__ == "__main__":
    main()
